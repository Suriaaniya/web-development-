# ToDoList

To-do list made for Colt Steele's webdev bootcamp

# What I Learned

* JQuery
* Project folders organization

